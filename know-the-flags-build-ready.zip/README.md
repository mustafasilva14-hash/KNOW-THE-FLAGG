# Know the Flags - Bölüm 1
1. Bu klasörü GitHub'da yeni bir depoya yükle.
2. Actions sekmesi > "Build APK" > Run workflow.
3. Bitince çalıştırmanın sayfasındaki "know-the-flags-apk" dosyasını indir (zip içinde app-release.apk).
Bayraklar derleme sırasında otomatik indirilir. Bayrağı olmayan kayıtlar (KKTC, özel statülü cumhuriyetler) oyunda otomatik gizlenir; assets/flags/ içine kod.svg (küçük harf, örn. xc.svg) koyunca görünür.
