Bayraklar derleme sırasında otomatik eklenir (flag-icons, MIT).
