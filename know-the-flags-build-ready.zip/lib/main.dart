import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

const navy = Color(0xFF0B1F44), teal = Color(0xFF19C7C1), card = Color(0xFF14305F);
final lang = ValueNotifier<String>('tr');
List<Country> all = [];
late SharedPreferences prefs;

const _s = {
  'tr': {'classic': 'Klasik Yarış', 'cont': 'Kıta Yarışları', 'settings': 'Ayarlar', 'language': 'Dil', 'q': 'Bu hangi ülkenin bayrağı?', 'score': 'Skor', 'over': 'Oyun bitti', 'again': 'Tekrar oyna', 'menu': 'Menü', 'best': 'En yüksek', 'flags': 'bayrak', 'AF': 'Afrika', 'AS': 'Asya', 'EU': 'Avrupa', 'NA': 'Kuzey Amerika', 'SA': 'Güney Amerika', 'OC': 'Okyanusya'},
  'en': {'classic': 'Classic Race', 'cont': 'Continent Race', 'settings': 'Settings', 'language': 'Language', 'q': 'Which country’s flag is this?', 'score': 'Score', 'over': 'Game over', 'again': 'Play again', 'menu': 'Menu', 'best': 'Best', 'flags': 'flags', 'AF': 'Africa', 'AS': 'Asia', 'EU': 'Europe', 'NA': 'North America', 'SA': 'South America', 'OC': 'Oceania'},
};
String t(String k) => _s[lang.value]![k] ?? k;

class Country {
  final String code, tr, en, cont;
  Country(this.code, this.tr, this.en, this.cont);
  String name() => lang.value == 'en' ? en : tr;
  String get asset => 'assets/flags/${code.toLowerCase()}.svg';
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  lang.value = prefs.getString('lang') ?? 'tr';
  final raw = jsonDecode(await rootBundle.loadString('assets/countries.json'));
  final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
  final have = manifest.listAssets().toSet();
  all = (raw['countries'] as List)
      .map((e) => Country(e['code'], e['tr'], e['en'], e['continent']))
      .where((c) => have.contains(c.asset))
      .toList();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Know the Flags',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: navy,
            colorScheme: const ColorScheme.dark(primary: teal, surface: card)),
        home: const Splash(),
      );
}

void go(BuildContext c, Widget p) => Navigator.push(c, MaterialPageRoute(builder: (_) => p));

Widget btn(String label, VoidCallback f, {bool primary = false}) => SizedBox(
      height: 56,
      child: primary
          ? FilledButton(
              style: FilledButton.styleFrom(backgroundColor: teal, foregroundColor: navy),
              onPressed: f,
              child: Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)))
          : OutlinedButton(
              style: OutlinedButton.styleFrom(side: const BorderSide(color: teal), foregroundColor: Colors.white),
              onPressed: f,
              child: Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
    );

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600));
  @override
  void initState() {
    super.initState();
    c.addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Menu()));
      }
    });
    c.forward();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: AnimatedBuilder(
            animation: c,
            builder: (_, __) {
              final v = Curves.easeOutCubic.transform(c.value);
              return Column(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                  width: 160,
                  height: 160,
                  child: CustomPaint(
                    painter: Ring(v),
                    child: Center(child: Opacity(opacity: v, child: const Icon(Icons.flag_rounded, size: 64, color: navy))),
                  ),
                ),
                const SizedBox(height: 24),
                Opacity(
                    opacity: v,
                    child: const Text('KNOW THE FLAGS',
                        style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 2))),
              ]);
            },
          ),
        ),
      );
}

class Ring extends CustomPainter {
  final double v;
  Ring(this.v);
  @override
  void paint(Canvas c, Size s) {
    final r = s.width / 2;
    c.drawArc(Rect.fromCircle(center: Offset(r, r), radius: r - 6), -pi / 2, 2 * pi * v, false,
        Paint()..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round..color = teal);
    c.drawCircle(Offset(r, r), (r - 24) * v, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(Ring o) => o.v != v;
}

class Menu extends StatelessWidget {
  const Menu({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: lang,
        builder: (ctx, _, __) => Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('KNOW THE FLAGS', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('${all.length} ${t('flags')}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 36),
                btn(t('classic'), () => go(ctx, Game(all)), primary: true),
                const SizedBox(height: 14),
                btn(t('cont'), () => pickCont(ctx)),
                const SizedBox(height: 14),
                btn(t('settings'), () => go(ctx, const Settings())),
              ]),
            ),
          ),
        ),
      );

  void pickCont(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: card,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final k in ['AF', 'AS', 'EU', 'NA', 'SA', 'OC'])
            Builder(builder: (b) {
              final pool = all.where((c) => c.cont == k).toList();
              return ListTile(
                title: Text(t(k), style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: Text('${pool.length}'),
                enabled: pool.length >= 4,
                onTap: () {
                  Navigator.pop(b);
                  go(ctx, Game(pool));
                },
              );
            }),
        ]),
      ),
    );
  }
}

class Settings extends StatelessWidget {
  const Settings({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: lang,
        builder: (_, __, ___) => Scaffold(
          appBar: AppBar(title: Text(t('settings')), backgroundColor: Colors.transparent),
          body: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('language'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              SegmentedButton<String>(
                segments: const [ButtonSegment(value: 'tr', label: Text('Türkçe')), ButtonSegment(value: 'en', label: Text('English'))],
                selected: {lang.value},
                onSelectionChanged: (s) {
                  lang.value = s.first;
                  prefs.setString('lang', s.first);
                },
              ),
            ]),
          ),
        ),
      );
}

class Game extends StatefulWidget {
  final List<Country> pool;
  const Game(this.pool, {super.key});
  @override
  State<Game> createState() => _GameState();
}

class _GameState extends State<Game> {
  final rnd = Random();
  late List<Country> q;
  int i = 0, lives = 3, score = 0, streak = 0, best = 0;
  List<Country> opts = [];
  Country? picked;
  bool done = false;

  @override
  void initState() {
    super.initState();
    q = [...widget.pool]..shuffle(rnd);
    _next();
  }

  void _next() {
    if (i >= q.length || lives <= 0) {
      done = true;
      best = max(prefs.getInt('best') ?? 0, score);
      prefs.setInt('best', best);
      return;
    }
    final cur = q[i];
    final src = widget.pool.length >= 4 ? widget.pool : all;
    final others = src.where((c) => c.code != cur.code).toList()..shuffle(rnd);
    opts = [cur, ...others.take(3)]..shuffle(rnd);
  }

  void _pick(Country o, Country cur) {
    if (picked != null) return;
    final ok = o.code == cur.code;
    setState(() {
      picked = o;
      if (ok) {
        score += 10 + min(streak, 10);
        streak++;
      } else {
        lives--;
        streak = 0;
      }
    });
    Future.delayed(Duration(milliseconds: ok ? 600 : 1200), () {
      if (!mounted) return;
      setState(() {
        i++;
        picked = null;
        _next();
      });
    });
  }

  Widget _opt(Country o, Country cur) {
    var bg = card;
    if (picked != null) {
      if (o.code == cur.code) {
        bg = const Color(0xFF1F9D63);
      } else if (o.code == picked!.code) {
        bg = const Color(0xFFD6334A);
      }
    }
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => _pick(o, cur),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Text(o.name(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (done) {
      return Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(t('over'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Text('${t('score')}: $score', textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, color: teal)),
              Text('${t('best')}: $best', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 32),
              btn(t('again'), () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Game(widget.pool))), primary: true),
              const SizedBox(height: 12),
              btn(t('menu'), () => Navigator.pop(context)),
            ]),
          ),
        ),
      );
    }
    final cur = q[i];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('${t('score')} $score'),
        actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('❤️' * lives + '🖤' * (3 - lives), style: const TextStyle(fontSize: 18))))],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: SizedBox(height: 180, child: Center(child: AspectRatio(aspectRatio: 4 / 3, child: SvgPicture.asset(cur.asset, key: ValueKey(cur.code))))),
            ),
            const SizedBox(height: 12),
            Text(t('q'), style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.9,
                physics: const NeverScrollableScrollPhysics(),
                children: opts.map((o) => _opt(o, cur)).toList(),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
